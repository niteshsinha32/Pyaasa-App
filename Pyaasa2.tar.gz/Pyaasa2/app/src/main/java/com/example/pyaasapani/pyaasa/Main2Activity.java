package com.example.pyaasapani.pyaasa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button loginButton = (Button) findViewById(R.id.editLogin);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText inputOne = (EditText) findViewById(R.id.editPhoneNumber);
                EditText inputTwo = (EditText) findViewById(R.id.editPassword);
                TextView phError = (TextView) findViewById(R.id.editPhoneError);
                //TextView pswrdError = (TextView) findViewById(R.id.editPassError);

                phError.setText("");
                //pswrdError.setText("");

                boolean valid = true;

                if( inputOne == null || inputOne.getText() == null || inputOne.getText().toString().isEmpty())
                {
                    phError.setText("! PHONE NUMBER EMPTY ");
                    //return;
                    valid = false;
                }
                else if(valid && inputOne.getText().toString().length() != 10 ){
                    //inputOne.setText("Enter 10 digit numer");
                    phError.setText("! NOT 10 DIGIT ");
                    valid = false;
                }

                if( inputTwo == null || inputTwo.getText() == null || inputTwo.getText().toString().isEmpty())
                {
                    phError.setText("! PASSWORD EMPTY ");
                    //return;
                    valid = false;
                }
                else if(inputTwo.getText().toString().length() < 4 || inputTwo.getText().toString().length()>8 ){
                    //inputOne.setText("Enter 10 digit numer");
                    phError.setText("Must be 4 to 8 characters");
                    valid=false;
                }

                if(! valid)
                    return;
                else
                {
                    Intent intentLogin = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(intentLogin);
                }
                // Long phoneNum = Long.parseLong(inputOne.getText().toString());
                // String passwrd = inputTwo.getText().toString();


            }
        });

        Button signUpBtn = (Button) findViewById(R.id.editSignUP) ;
        signUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentSignUp =  new Intent(getApplicationContext(), SignUpActivity.class);
                startActivity(intentSignUp);
            }
        });
    }}