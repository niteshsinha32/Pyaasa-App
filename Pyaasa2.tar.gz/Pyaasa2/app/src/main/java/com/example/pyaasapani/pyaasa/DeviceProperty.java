package com.example.pyaasapani.pyaasa;

//import com.example.android.basicpermissions.camera.CameraPreviewActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.util.Log;
import java.util.List;
import android.telephony.TelephonyManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import org.w3c.dom.Text;


public class DeviceProperty extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final int MY_PERMISSION_REQUEST_RESULT = 0;
    private static final String TEXT_REQUESTED_APP_PERMISSION_GRANTED = "Permission granted by user";
    private static final String TEXT_REQUESTED_APP_PERMISSION_DENIED = "Permission denied by user";
    private static final String TEXT_REQUESTED_APP_PERMISSION_AVAILABLE = "Permission already available";
    private static final String TEXT_REQUESTED_APP_PERMISSION_NOT_AVAILABLE = "Permission NOT available";
    private static final String TEXT_PERMISSION_REQUIRED = "Permission required";
    private static final String TEXT_OK = "OK";
    public String sysResourcePermission ;//

    private View mLayout ;

     //String  sysResourcePermission= myIntent.getStringExtra("requestedResName");


    @Override
    protected void onCreate(Bundle savedInstances){
        super.onCreate(savedInstances);
        setContentView(R.layout.activity_device_property);
       // savedInstances. resourceName
        Bundle extras = this.getIntent().getExtras();
        Intent myIntent = getIntent();
         sysResourcePermission= myIntent.getStringExtra("requestedResName");
        //if(sysResourcePermission == null)
          //  return;
        mLayout= findViewById(R.id.perms_layout);
        Button chkPerms = (Button) findViewById(R.id.btnChkPerms);
        chkPerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAppPermission();
            }
        });

    }

        private void showAppPermission(){
            if(ActivityCompat.checkSelfPermission(this, sysResourcePermission) == PackageManager.PERMISSION_GRANTED)
            {
                Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_AVAILABLE,Snackbar.LENGTH_INDEFINITE);
                    startAppPermittedActivity();
            }
            else
            {
                Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_NOT_AVAILABLE,Snackbar.LENGTH_INDEFINITE);
                requestAppPermission();
            }
        }

        private void requestAppPermission(){

            if(ActivityCompat.shouldShowRequestPermissionRationale(this,sysResourcePermission)){
                Snackbar.make(mLayout,TEXT_PERMISSION_REQUIRED, Snackbar.LENGTH_INDEFINITE).setAction(TEXT_OK, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ActivityCompat.requestPermissions(DeviceProperty.this,new String[]{sysResourcePermission},MY_PERMISSION_REQUEST_RESULT);
                    }
                }).show();
            }
            else
            {
                Snackbar.make(mLayout, TEXT_REQUESTED_APP_PERMISSION_NOT_AVAILABLE , Snackbar.LENGTH_INDEFINITE).show();
                ActivityCompat.requestPermissions(this, new String[]{sysResourcePermission},MY_PERMISSION_REQUEST_RESULT);

            }
        }

        private void startAppPermittedActivity(){

            if(ActivityCompat.checkSelfPermission(this,sysResourcePermission)==PackageManager.PERMISSION_GRANTED){
                Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_AVAILABLE,Snackbar.LENGTH_INDEFINITE);
                TelephonyManager tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
                String simTwoNumber = "", simOneNumber="";
                try {

                    //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                        SubscriptionManager subManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                        List<SubscriptionInfo> subInfoList = null;
                        subInfoList = subManager.getActiveSubscriptionInfoList();
                        if (subInfoList != null && subInfoList.size() > 0) {
                            switch (subInfoList.size()) {
                                case 2:
                                    simTwoNumber = subInfoList.get(1).getNumber();
                                case 1:
                                    simOneNumber = subInfoList.get(0).getNumber();
                                    break;
                                default:
                                    break;
                            }
                        }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                String simSerialNo = tm.getSimSerialNumber();
                String simNo1 =  tm.getLine1Number();
                String nwOperator = tm.getNetworkOperator();
                String nwOperatorName = tm.getNetworkOperatorName();
                String simOperator = tm.getSimOperator();
                String simOperatorName = tm.getSimOperatorName();
                Log.d("mobile 1 no",": "+simOneNumber);
                Log.d("mobile 2 no",": "+simTwoNumber);
                Log.d("sim serial no",": "+simSerialNo);
                Log.d("nwOperator",": "+nwOperator);
                Log.d("nwOperatorName",": "+nwOperatorName);
                Log.d("simOperator",": "+simOperator);
                Log.d("simOperatorName",": "+simOperatorName);
                TextView txtNo = (TextView) findViewById(R.id.textSimNo);
                txtNo.setText("Mobile number 1 is : " + simNo1);

            }
            else
                requestAppPermission();
        }
        @Override
        public void onRequestPermissionsResult(int requestCode ,String[] permissions ,  int[] grantResults){

          //  Log.d("request code" , " value :  " + requestCode);
            //Log.d(" grant results ", " value : " + grantResults[0]);
            //Log.d("g res length" , " : " + grantResults.length);

                // BEGIN_INCLUDE(onRequestPermissionsResult)
                if (requestCode == MY_PERMISSION_REQUEST_RESULT) {
                    // Request for camera permission.
                    if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        // Permission has been granted. Start camera preview Activity.
                        Snackbar.make(mLayout, TEXT_REQUESTED_APP_PERMISSION_GRANTED,
                                Snackbar.LENGTH_SHORT)
                                .show();
                        //startCamera();
                    } else {
                        // Permission request was denied.
                        Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_DENIED,
                                Snackbar.LENGTH_SHORT)
                                .show();
                    }
                }
        }
}