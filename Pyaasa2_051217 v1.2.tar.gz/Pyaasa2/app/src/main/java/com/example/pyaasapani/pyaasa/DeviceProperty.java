package com.example.pyaasapani.pyaasa;

//import com.example.android.basicpermissions.camera.CameraPreviewActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.util.Log;
import java.util.List;
import android.telephony.TelephonyManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import org.w3c.dom.Text;


public class DeviceProperty extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final int MY_PERMISSION_REQUEST_RESULT = 0;
    private static final String TEXT_REQUESTED_APP_PERMISSION_GRANTED = "Permission granted by user";
    private static final String TEXT_REQUESTED_APP_PERMISSION_DENIED = "Permission denied by user";
    private static final String TEXT_REQUESTED_APP_PERMISSION_AVAILABLE = "Permission already available";
    private static final String TEXT_REQUESTED_APP_PERMISSION_NOT_AVAILABLE = "Permission NOT available";
    private static final String TEXT_PERMISSION_REQUIRED = "Enable Permission";
    private static final String TEXT_OK = "OK";
    String sysResourcePermission;
   /** public DeviceProperty(){
        this.sysResourcePermission=Manifest.permission.READ_CONTACTS;
    }
    public DeviceProperty(String askedPermission){
          this.sysResourcePermission = askedPermission;
    }
**/

   // private View mLayout ;

     //String  sysResourcePermission= myIntent.getStringExtra("requestedResName");


    @Override
    protected void onCreate(Bundle savedInstances){
        super.onCreate(savedInstances);
        setContentView(R.layout.activity_device_property);
       // savedInstances. resourceName
        Bundle extras = this.getIntent().getExtras();
        Intent myIntent = getIntent();
        sysResourcePermission= myIntent.getStringExtra("requestedResName");
        //Object itemSelected;
         // SPINNER DROPDOWN
        Spinner dropdown = (Spinner)findViewById(R.id.spinner1);
        String str1[];
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, retrievePermissions(this));
//set the spinners adapter to the previously created one.
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropdown.setAdapter(adapter);
        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Object itemSelected  = adapterView.getItemAtPosition(i);
                sysResourcePermission= itemSelected.toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                sysResourcePermission= Manifest.permission.READ_PHONE_STATE;
            }
        });

        //sysResourcePermission=
        //for(int i=0;i<Manifest.permission.)
        //if(sysResourcePermission == null)
          //  return;
        //mLayout= findViewById(R.id.myView1);
        Button chkPerms = findViewById(R.id.btnAskPerms);
        chkPerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAppPermission();
            }
        });

    }

        public void showAppPermission(){
            if(ActivityCompat.checkSelfPermission(this, sysResourcePermission) == PackageManager.PERMISSION_GRANTED)
            {
                //Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_AVAILABLE,Snackbar.LENGTH_INDEFINITE);
                    startAppPermittedActivity();
               // return true;
            }
            else
            {
               // Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_NOT_AVAILABLE,Snackbar.LENGTH_INDEFINITE);
               // return false;
                //Log.d("location "," here in else part of showapppermission");
                requestAppPermission();
            }
        }

        public void requestAppPermission() {
           // Log.d("location ", " here in requestapppermission");
           // if (ActivityCompat.shouldShowRequestPermissionRationale(this, sysResourcePermission)) {
                // Snackbar.make(mLayout,TEXT_PERMISSION_REQUIRED, Snackbar.LENGTH_INDEFINITE).setAction(TEXT_OK, new View.OnClickListener() {
                //@Override
                // public void onClick(View view) {
               // Log.d("location ", " here in if part of shouldshowreq rationl");
                ActivityCompat.requestPermissions(DeviceProperty.this, new String[]{sysResourcePermission}, MY_PERMISSION_REQUEST_RESULT);
                startAppPermittedActivity();
          //  }
            //).show();
            //else
               // Log.d("location ", " here in else of shouldshowreq permission");
        }

        public void startAppPermittedActivity(){
            String simNumber[] = {"",""};
            if(ActivityCompat.checkSelfPermission(this,sysResourcePermission)==PackageManager.PERMISSION_GRANTED){
                //Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_AVAILABLE,Snackbar.LENGTH_INDEFINITE);
                //Log.d("location ", " here in if prt of showapp  permited activty");
                TelephonyManager tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);

                try {

                    //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                        SubscriptionManager subManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                        List<SubscriptionInfo> subInfoList = null;
                        subInfoList = subManager.getActiveSubscriptionInfoList();
                        if (subInfoList != null && subInfoList.size() > 0) {
                            switch (subInfoList.size()) {
                                case 2:
                                    simNumber[1] = subInfoList.get(1).getNumber();

                                case 1:
                                    simNumber[0] = subInfoList.get(0).getNumber();
                                    break;
                                default:
                                    break;
                            }
                        }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                String simSerialNo = tm.getSimSerialNumber();
                String simNo1 =  tm.getLine1Number();
                String nwOperator = tm.getNetworkOperator();
                String nwOperatorName = tm.getNetworkOperatorName();
                String simOperator = tm.getSimOperator();
                String simOperatorName = tm.getSimOperatorName();
                Log.d("mobile 1 no",": "+simNumber[0]);
                Log.d("mobile 2 no",": "+simNumber[1]);
               /** Log.d("sim serial no",": "+simSerialNo);
                Log.d("nwOperator",": "+nwOperator);
                Log.d("nwOperatorName",": "+nwOperatorName);
                Log.d("simOperator",": "+simOperator);
                Log.d("simOperatorName",": "+simOperatorName);
                **/
                TextView txtNo = (TextView) findViewById(R.id.textSimNo);
                txtNo.setText("Mobile number 1 is : " + simNo1);


            }

            else
               // Log.d("location ", " here in else of showapp  permited activty");
            //return simNumber;
            return;
        }
        @Override
        public void onRequestPermissionsResult(int requestCode ,String[] permissions ,  int[] grantResults){

          //  Log.d("request code" , " value :  " + requestCode);
            //Log.d(" grant results ", " value : " + grantResults[0]);
            //Log.d("g res length" , " : " + grantResults.length);

                // BEGIN_INCLUDE(onRequestPermissionsResult)
                if (requestCode == MY_PERMISSION_REQUEST_RESULT) {
                    // Request for camera permission.
                    if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        // Permission has been granted. Start camera preview Activity.
                        //Snackbar.make(mLayout, TEXT_REQUESTED_APP_PERMISSION_GRANTED,
                              //  Snackbar.LENGTH_SHORT)
                               // .show();
                        //startCamera();
                    } else {
                        // Permission request was denied.
                        //Snackbar.make(mLayout,TEXT_REQUESTED_APP_PERMISSION_DENIED,
                          //      Snackbar.LENGTH_SHORT)
                            //    .show();
                    }
                }
        }

    public static String[] retrievePermissions(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_PERMISSIONS).requestedPermissions;
        } catch (PackageManager.NameNotFoundException e){
            e.printStackTrace();
        }
        throw new RuntimeException ("This should have never happened."); // I'd return null and Log.wtf(...) in production
    }
}